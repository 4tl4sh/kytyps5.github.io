ASTRO BOT (PPSA21567) delta-time patch with physics and crash fixes for KytyPS5
=================================================================================

Pick the folder that matches your game version and emulator:
  Astro Bot 1.018 (version 01.018.000)\PPSA21567.json                         KytyPS5 / U59 builds
  Astro Bot 1.019 (version 01.019.000)\PPSA21567.json                         KytyPS5 / U59 builds
  Astro Bot 1.018 (version 01.018.000) - KytyPS5 DLSS fork\PPSA21567.json     KytyPS5 DLSS fork
  Astro Bot 1.019 (version 01.019.000) - KytyPS5 DLSS fork\PPSA21567.json     KytyPS5 DLSS fork

The emulator only loads a patch whose version matches the game; with the wrong one its log
says "cheat file does not match the loaded game". Your game's version is APP_VER in the
emulator log, or contentVersion in sce_sys\param.json.

Install: copy PPSA21567.json into the emulator's _Patches folder (replace the old one),
then close and reopen the launcher. Turn options on or off in the launcher's cheats menu.
Keep the options in the order they are in the file.

The 1.018 version is what has been played and tested. The 1.019 versions are ports: every
patched spot was matched and checked against the 1.019 game code, but nobody has played
them on 1.019 yet. Please report if something doesn't work there.

Credits: the graphics, delta-time, R1+X, frame cap and resolution options (including the
DLSS resolutions) come from the community patches shared on Discord. The fixes, memory and
video options were added on top of them.


What each option does
---------------------
"Pick one" = turn on only one option of that group.

Graphics
- Deferred-lighting renderer: simpler lighting mode the emulator draws correctly and faster.
- Disable GI: turns off bounced lighting. Big performance boost, slightly flatter lighting.
- Fixed render resolution (pick one): the game's internal resolution. 1080p is the fastest
  of the standard ones; the DLSS fork adds lower DLSS input resolutions.

Timing
- Decouple (delta time): the game runs at normal speed below 60 fps instead of slow motion.
- R1+X toggle: press R1+X in game to switch delta time off/on. Off = slow motion, but the
  game runs exactly as on PS5 at 60 fps. Use it if something still acts strange.
- Precise frame cap (pick one): caps the frame rate at 30, 40, 60, 90, 120 or 144 fps. A cap at or
  just below what your PC can hold (30 or 40 for most PCs) gives the steadiest frame pacing.
- Disable CPU frame-limiter sleep: experimental, leave off.

General stability and physics fixes (one option, keep it on together with Decouple)
Everything the game gets wrong when it runs below 60 fps with delta time, in one toggle:
- Two Havok physics crashes (after stutters, level loads and in some stages).
- Delta time capped at 1/20 s: below 20 fps the game slows down a little instead of taking
  huge steps (fixes the wobbling monkey arms and exploding models).
- No speed-up for a few seconds after the frame rate rises.
- Bot rescue: rescued bots and the controller show up instead of softlocking. That scene
  plays in slow motion, then normal speed comes back on its own.
- Rope bridges (like the Ape Escape jungle bridge) no longer shake apart and break.
- Cloth and inflatables (zipper squid, air bubbles) stay round instead of crumpling.
- Jack-in-the-box bounce pads launch Astro properly (no getting stuck in Fan Club).
- Astro's jumps reach the same height as at 60 fps.
- Punched objects (crates, cans and other physics props) fly as far as at 60 fps instead of
  several times farther.
- Water, paint and other fluids hold together and move at the right speed, and taps and
  sources pour the same amount per second as at 60 fps. Costs extra GPU time while a lot
  of fluid is on screen.
Optional: "Stricter delta time cap 1/30 s" (needs the general fixes) slows the game a
little below 30 fps instead of 20 fps. Most stable, for slower PCs.

Memory (optional, for less VRAM)
- Mip bias 1080p / +1 (pick one): slightly softer / blurrier textures, less VRAM.
- 4K textures at 2K: the largest textures load at half resolution.
- Model LOD x0.5 / x0.25 (pick one): simpler models appear closer to you; small details may pop in.

Videos
- Videos at real speed: videos play at the right speed instead of half speed (not 4K videos).
- Skip PS Studios intro: skips the 4K logo video, which plays very slowly in the emulator.

Default setup in these files: renderer, Disable GI, Decouple, R1+X, the 60 fps frame cap,
1080p (DLSS fork: FHD DLSS Performance), the general fixes and both video options are on.
Everything else is off.
